/* Sample files: Intermediate JS */
/* Working exercise */
