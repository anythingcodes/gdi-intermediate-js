/* Sample files: Intermediate JS */
/* Working exercise */

// What to do with fetched geo data.
var onGeoComplete = function(geoloc) {
    if (geoloc && geoloc.coords) {
        var coordsObj = {
            'latitude': geoloc.coords.latitude,
            'longitude': geoloc.coords.longitude
        };

        // Convert to JSON and write to a cookie.
        var coordsJSON = JSON.stringify(coordsObj);
        document.cookie = 'coords=' + coordsJSON + ';max-age=' + 60*20;
        console.log('coords cookie set');
        getData.done(function(data) {
            console.log(data, ' from geolocation');
            createDirections(coordsObj, data);
        });

    } else {
        console.log('no geo coordinates');
    }
};
navigator.geolocation.getCurrentPosition(onGeoComplete);

// What to do on successful AJAX response.
function onSuccess(response) {
    var responseObj = response && JSON.parse(response);
    console.log(typeof response);
    console.log(typeof responseObj);
    console.log(responseObj && responseObj.name);

    var user = responseObj.name;
    $('#content').append('<p>' + user + '</p>');
};

var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://jsonplaceholder.typicode.com/users/2/');
xhr.send(null);
xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
        if (xhr.status === 200) {
            onSuccess(xhr.responseText);
        } else {
            console.log('Error: ' + xhr.status);
        }
    }
};

// Retrieve a cookie by name.
var getCookie = function(name) {
    var re = new RegExp(name + "=([^;]+)");
    var value = re.exec(document.cookie);
    return value && value[1] || '';
}

// Recreate the AJAX request with jQuery.
var getData = $.ajax({
    url: 'https://my-json-server.typicode.com/cfarm/gdi-js-data/users/10',
    dataType: 'jsonp'
})
.done(function(data) {
    getUsername(data);
})
.fail(function(jqXHR, textStatus) {
    console.error('Error:' + textStatus);
});

// Get the username from the response data.
function getUsername(response) {
    var user = response.username;
    var userId = response.id;
    $('#content').append('<p id=user-' + userId + '>' + user + '</p>');
};

// Combine promises to make multiple things happen when the AJAX request is finished.
getData.always(function() {
    console.log('Piggyback off the original request, even if it fails');
});

getData.done(function() {
    console.log('%cAJAX request is finished', 'background-color: green; color: lightgreen; padding: 4px');
});

function getUserId(response) {
    return response.id;
}

function getLocation(response) {
    var location = response.address.geo;
    return location;
}

function createMapLink(response) {
    var latitude = getLocation(response).lat;
    var longitude = getLocation(response).lng;
    var userId = getUserId(response);
    var mapLink = 'https://www.google.com/maps/?q=' + latitude + ',' + longitude;

    $('#user-' + userId).append(' <a href="' + mapLink + '">lives here</a>.');
}

getData.done(function(data) {
    var locationData = getLocation(data);
    console.log(locationData);

    createMapLink(data);
});

function createDirections(origin, destination) {
    // get coordinates from the browser geolocation
    var localLat = origin.latitude;
    var localLong = origin.longitude;
    
    // get coordinates from the AJAX request
    var userLat = getLocation(destination).lat;
    var userLong = getLocation(destination).lng;

    // create directions link w/coordinates
    var directionsLink = 'https://www.google.com/maps/?saddr=' + localLat + ',' + localLong + '&z=16&daddr=' + userLat + ',' + userLong;

    console.log(origin);

    // add directions link to the correct element matching the user id
    var userId = getUserId(destination);
    $('#user-' + userId).append(' <a href="' + directionsLink + '">Get directions to go visit</a>.');
}